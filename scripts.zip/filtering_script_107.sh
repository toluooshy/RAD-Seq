conda activate py27
conda activate rad-env
cd wdecdc/d/cf/fc/d
fd/ed/s/3e/cfvv/ --vcf (ORIGINAL VCF)--out _filtered_min10x_mm_0.5_m_0.2_maf_0.02 --min-meanDP 10 --max-missing 0.5 --recode
fd/ed/s/3e/cfvv/ --vcf (VCF FROM 1st FUNCTION) --out (LIST OF SINGLETONS) --singletons
fd/ed/s/3e/cfvv/ --vcf (VCF FROM 1st FUNCTION) --out (FILE WITHOUT SINGLETONS) --exclude-positions(LIST OF SINGLETONS) --recode
fd/ed/s/3e/cfvv/ --vcf _filtered_min10x_final.recode.vcf --out _missing_mm_0.5_m_0.2_maf_0.02 --missing-indv
awk <_missing.imiss ' $5>0.2 <built-in function print> ' >_to_exclude.txt
fd/ed/s/3e/cfvv/ --vcf _filtered_min10x_final.recode.vcf --out _vcffilter --remove_to_exclude.txt --recode
fd/ed/s/3e/cfvv/ --vcf _vcf.recode.vcf --out _final_vcffilter_mm_0.5_m_0.2_maf_0.02 --maf 0.02